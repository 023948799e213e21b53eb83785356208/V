
if |C| then 
    if Stack[|A|] then
        InstrPoint = InstrPoint + 1;
    end
elseif Stack[|A|] then

else 
    InstrPoint = InstrPoint + 1;
end
