const express = require("express")
const bodyParser = require('body-parser');
const app = express()
app.use(bodyParser.urlencoded({ extended: true }))
const main = require('../src/index');
const config = require('../config.json');

let settings = {
    '__VERSION__': '0.2.4',

    'Debug': false,
    'SkipMinify': false,
    'useRewriteGenerator': false,

    'BeautifyDebug': true,
    'PrintStep': false,
    'JIT': false,
    'Watermark': `fortnite hack`,
    'Uid': createID(4),

    'AntiTamper': true,
    'MaximumSecurity': true,
    'UseSuperops': false
};

async function obfuscate(content, message) {
    console.log("obfuscating...")

    try {
        var obfuscated = await main.obfuscate(content, settings);
    } catch(err) {
        console.log('failed to obfuscate')
        return;
    }


    return obfuscated[0]
};


function createID(length) {
    var result = '';
    var characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz';
    var charactersLength = characters.length;

    for (var i = 0; i < length; i++) {
        result += characters.charAt(Math.floor(Math.random() * charactersLength));
    }
   
    return result;
};

app.post("/obf", (req, res) => {
  console.log(req.body.toString())
  let result = obfuscate(req.body.toString(), "a")

  
  return res.send(result)
})

app.listen(8080, console.log("web up"))