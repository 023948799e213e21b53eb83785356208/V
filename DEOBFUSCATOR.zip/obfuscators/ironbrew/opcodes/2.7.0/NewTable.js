module.exports = {
    NewTableB0: {
        String: "Stk[Inst[OP_A]]={};",
        Create: function(instruction) {
            return instruction
        }
    }
}